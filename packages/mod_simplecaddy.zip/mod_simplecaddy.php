<?php
/**
* Package SimpleCaddy 2.0 for Joomla 2.5
* @Copyright Henk von Pickartz 2006-2013
*/
/** ensure this file is being included by a parent file */
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );
jimport('joomla.application.component.router');
require_once (JPATH_SITE.'/components/com_content/helpers/route.php');
//$mainframe=JFactory::getApplication();

require_once (JPATH_ROOT.'/components/com_simplecaddy/simplecaddy.class.php');
require_once (JPATH_ROOT.'/components/com_simplecaddy/simplecaddy.cart.class.php');
require_once (JPATH_ROOT.'/components/com_simplecaddy/simplecaddy.content.class.php');
$showtotals=$params->get("productshow");

$a=getCaddy($showtotals);
$itemid	= $params->get('DisplayID');
$nextcid=$params->get("nextcid");

$sp=new sccontent();
$sp->load($nextcid);
$url =JUri::root(). ContentHelperRoute::getArticleRoute($sp->id. ":". $sp->alias, $sp->catid) ;
//$mainframe->redirect($url);
//$url="index.php?option=com_content&view=article&id=$nextcid";

echo $a;
echo "<div align='center'>
	<form name='frmcheckout' method ='post' action='$url'>
	<input type='submit' class='btnshowcart' name='submit' value='".JText::_('SC_SHOW_CART')."' />
	</form></div>
";

function getCaddy($showtotals) {
	$cfg=new sc_configuration();
	$tsep=$cfg->get('thousand_sep');
	$dsep=$cfg->get('decimal_sep');
	$decs=$cfg->get('decimals');
	$currency=$cfg->get('currency');
	$curralign=$cfg->get('curralign');


	$cart2=new cart2();
	$cart=$cart2->readCart();
	if (!$cart) {
		echo JText::_('SC_CART_EMPTY');
		return;
	}
	$gtotal=0;
	$nombre=0;
	$emptycart=true;
	$html = "<table width='100%' border='0'>";
    if ($showtotals==0) {
    	$nombre=$cart2->getCartNumbers();
    }
    else
    {
        $nombre=$cart2->getCartQuantities();
    }
	$carttotal=$cart2->getCartTotal();
	if ($nombre==0) {
		$html=JText::_('SC_CART_EMPTY');
	}
	else
	{
		$total=number_format($carttotal, $decs, $dsep, $tsep);
		$stotal=($curralign==1?"$currency&nbsp;$total":"$total&nbsp;$currency");

		$html .="<tr><td colspan=2>".JText::_('SC_YOUR_CART_CONTAINS')." <strong>$nombre</strong> ".(($nombre==1)?JText::_('SC_PRODUCT'):JText::_('SC_PRODUCTS'))."</td></tr>";
// the following line provides for Polish grammar
//		$html .="<tr><td colspan=2>".JText::_('SC_YOUR_CART_CONTAINS')." <strong>$nombre</strong> ".(($nombre==1)?JText::_('SC_PRODUCT'):( (($nombre>1) and ($nombre<=4))?JText::_('SC_PRODUCTS'):JText::_('SC_PRODUCTS_2')) )."</td></tr>";

			$html .="<tr><td>".JText::_('SC_TOTAL')."</td><td align=right nowrap=1>".$stotal."</td></tr>";

		$html .="</table>";
	}
	return $html;
}
?>
